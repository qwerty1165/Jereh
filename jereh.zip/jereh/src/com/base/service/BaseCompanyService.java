package com.base.service;

import com.base.entity.BaseCompany;

public interface BaseCompanyService {
	
	public BaseCompany searchBaseCompany();
	
	public int modifyBaseCompany(BaseCompany baseCompany);
	
}
