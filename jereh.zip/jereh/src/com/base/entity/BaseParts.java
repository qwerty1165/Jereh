package com.base.entity;

import java.util.Date;

public class BaseParts {
	
	private String partsCode; //���
	private String partsName;  //����
	private String spell;  //�������ƴ��
	private String partsCategory; //������
	private String partsBrand;  //���Ʒ��
	private String partsNo;  //	����
	private String partsGeneralPartsNo;//ͨ�ü���
	private String partsModel;//�ͺ�
	private String partsModelOld;//���ͺ�
	private String partsSize;//����ߴ�
	private String partsWeight;//�������
	private String partsImg;//���ͼƬ
	private String partsUnit;//�����λ
	private double salePrice;//���ۼ۸�
	private double costPrice; //ƽ���ɱ���
	private String isShow;//�Ƿ���Ч
	private String remarks;//��ע
	private Date addDate;//��������
	private String addUser;//�����û�
	private String addUserName;//�����û�����
	private String addIp;//����IP
	private String compCode;//������˾
	public String getPartsCode() {
		return partsCode;
	}
	public void setPartsCode(String partsCode) {
		this.partsCode = partsCode;
	}
	public String getPartsName() {
		return partsName;
	}
	public void setPartsName(String partsName) {
		this.partsName = partsName;
	}
	public String getSpell() {
		return spell;
	}
	public void setSpell(String spell) {
		this.spell = spell;
	}
	public String getPartsCategory() {
		return partsCategory;
	}
	public void setPartsCategory(String partsCategory) {
		this.partsCategory = partsCategory;
	}
	public String getPartsBrand() {
		return partsBrand;
	}
	public void setPartsBrand(String partsBrand) {
		this.partsBrand = partsBrand;
	}
	public String getPartsNo() {
		return partsNo;
	}
	public void setPartsNo(String partsNo) {
		this.partsNo = partsNo;
	}
	public String getPartsGeneralPartsNo() {
		return partsGeneralPartsNo;
	}
	public void setPartsGeneralPartsNo(String partsGeneralPartsNo) {
		this.partsGeneralPartsNo = partsGeneralPartsNo;
	}
	public String getPartsModel() {
		return partsModel;
	}
	public void setPartsModel(String partsModel) {
		this.partsModel = partsModel;
	}
	public String getPartsModelOld() {
		return partsModelOld;
	}
	public void setPartsModelOld(String partsModelOld) {
		this.partsModelOld = partsModelOld;
	}
	public String getPartsSize() {
		return partsSize;
	}
	public void setPartsSize(String partsSize) {
		this.partsSize = partsSize;
	}
	public String getPartsWeight() {
		return partsWeight;
	}
	public void setPartsWeight(String partsWeight) {
		this.partsWeight = partsWeight;
	}
	public String getPartsImg() {
		return partsImg;
	}
	public void setPartsImg(String partsImg) {
		this.partsImg = partsImg;
	}
	public String getPartsUnit() {
		return partsUnit;
	}
	public void setPartsUnit(String partsUnit) {
		this.partsUnit = partsUnit;
	}
	public double getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}
	public double getCostPrice() {
		return costPrice;
	}
	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}
	public String getIsShow() {
		return isShow;
	}
	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Date getAddDate() {
		return addDate;
	}
	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}
	public String getAddUser() {
		return addUser;
	}
	public void setAddUser(String addUser) {
		this.addUser = addUser;
	}
	public String getAddUserName() {
		return addUserName;
	}
	public void setAddUserName(String addUserName) {
		this.addUserName = addUserName;
	}
	public String getAddIp() {
		return addIp;
	}
	public void setAddIp(String addIp) {
		this.addIp = addIp;
	}
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	
}
