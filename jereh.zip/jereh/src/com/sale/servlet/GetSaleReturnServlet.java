package com.sale.servlet;

import javax.servlet.http.HttpServlet;

public class GetSaleReturnServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public GetSaleReturnServlet() {
		super();
	}

}
