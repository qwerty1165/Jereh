package com.sale.dao;

public class SaleReturnDetailDao {

}
