package com.sale.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.common.dao.BaseDao;
import com.sale.dao.SaleOrder_DetailDao;
import com.sale.entity.SaleOrder_Detail;

public class SaleOrder_DetailDaoImpl extends BaseDao implements SaleOrder_DetailDao {

	@Override
	public SaleOrder_Detail findDetailByCode(String sCode) {
		String sql="select * from saleorder_detail where scode="+sCode;
		ResultSet rs=super.executeQuery(sql);
		SaleOrder_Detail sd=new SaleOrder_Detail();
		try {
			while(rs.next()){
				sd=new SaleOrder_Detail();
				sd.setsCode(rs.getString("scode"));
				sd.setsCode(rs.getString("scode"));
				sd.setsCode(rs.getString("scode"));
				sd.setsCode(rs.getString("scode"));
				sd.setsCode(rs.getString("scode"));
				sd.setsCode(rs.getString("scode"));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


}
