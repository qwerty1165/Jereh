package com.stock.dao;

public interface StockOutDetailDao {

}
